# Lab8_mySql

link video: https://drive.google.com/file/d/1KzSPTUHvh2U2NLSrTeRHNWT4wyVlT1DW/view?usp=sharing